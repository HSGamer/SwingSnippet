
package me.hsgamer.testdatabase;

import com.microsoft.sqlserver.jdbc.SQLServerDriver;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author huynh
 */
public class TestDatabase {

    public static void main(String[] args) {
        String user = "sa";
        String password = "password";
        String url = "jdbc:sqlserver://;serverName=localhost;databaseName=Student;trustServerCertificate=true";
        
        try {
            Class.forName(SQLServerDriver.class.getName()); // Nap driver
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(TestDatabase.class.getName()).log(Level.SEVERE, null, ex);
            return;
        }
        
        Connection connection;
        try {
            connection = DriverManager.getConnection(url, user, password); // Ket noi database
        } catch (SQLException ex) {
            Logger.getLogger(TestDatabase.class.getName()).log(Level.SEVERE, null, ex);
            return;
        }
        
        
        try (Statement statement = connection.createStatement()) { // Tao mot doi tuong truy van database
            ResultSet rs = statement.executeQuery("SELECT * FROM Info"); // Thuc hien truy van
            while (rs.next()) { // Thuc hien duyet ket qua tung dong
                String s = String.join(", ", 
                        "ID: " + rs.getInt("ID"), // Lay gia tri cua mot o co ten la ID
                        "Name: " + rs.getNString("Name"), // Lay gia tri cua mot o co ten la Name
                        "Is Female: " + rs.getObject("IsFemale", Boolean.class) // Lay gia tri cua mot o co ten la IsFemale
                );
                System.out.println(s);
            }
        } catch (SQLException ex) {
            Logger.getLogger(TestDatabase.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        try (PreparedStatement statement = connection.prepareStatement("INSERT INTO Info(Name, IsFemale) VALUES (?, ?)")) { // Chuan bi mot doi tuong truy van database
            // Thay the gia tri o cac dau cham hoi ? trong lenh truy van
            statement.setNString(1, "Hehe");
            statement.setObject(2, null);
            
            // Thuc hien lenh truy van, khong quan tam ket qua
//            statement.execute();
            
            // Thuc hien lenh truy van, lay gia tri so dong bi anh huong do lenh
            int changeCount = statement.executeUpdate();
            System.out.println("Nhung dong da thay doi: " + changeCount);
        } catch (SQLException ex) {
            Logger.getLogger(TestDatabase.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
