
package me.hsgamer.javaproject6;

/**
 *
 * @author huynh
 */
public class JavaProject6 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
