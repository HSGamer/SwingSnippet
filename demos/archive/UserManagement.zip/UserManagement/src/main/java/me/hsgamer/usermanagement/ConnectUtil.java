package me.hsgamer.usermanagement;

import com.microsoft.sqlserver.jdbc.SQLServerDriver;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectUtil {
    // Ham khoi tao cua Class. Chay mot lan khi truy cap Class lan dau tien.
    static {
        // Nap driver SQL
        try {
            Class.forName(SQLServerDriver.class.getName());
        } catch (ClassNotFoundException ex) {
            throw new RuntimeException(ex);
        }

    }
    
    public static Connection getConnection() {
        String username = "sa";
        String password = "CR222!123";
        String url = "jdbc:sqlserver://;serverName=localhost;databaseName=UserManage;trustServerCertificate=true";
        
        try {
            return DriverManager.getConnection(url, username, password);
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }
}
