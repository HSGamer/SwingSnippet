
package me.hsgamer.usermanagement;

import java.sql.SQLException;

/**
 *
 * @author huynh
 */
public class UserManagement {

    public static void main(String[] args) throws SQLException {
        new LoginForm().setVisible(true);
    }
}
