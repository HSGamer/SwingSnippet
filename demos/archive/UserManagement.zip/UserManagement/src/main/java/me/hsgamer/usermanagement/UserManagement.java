package me.hsgamer.usermanagement;

import javax.swing.SwingUtilities;

/**
 *
 * @author huynh
 */
public class UserManagement {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new LoginForm().setVisible(true);
            }
        });
    }
}
