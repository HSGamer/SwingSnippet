
package me.hsgamer.javaproject7;

/**
 *
 * @author huynh
 */
public class JavaProject7 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
