
package me.hsgamer.chatproject;

/**
 *
 * @author huynh
 */
public class ChatProject {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
