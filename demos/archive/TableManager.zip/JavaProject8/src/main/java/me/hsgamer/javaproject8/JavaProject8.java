
package me.hsgamer.javaproject8;

/**
 *
 * @author huynh
 */
public class JavaProject8 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
